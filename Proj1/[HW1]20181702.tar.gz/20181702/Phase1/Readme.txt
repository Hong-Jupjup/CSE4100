<Project1 Phase 1: Building and Testing Your Shell>

- Goal of This Phase:	
	Implement basic commands built in the basic internal shell
		such as cd, ls, mkdir, etc...

- Usable Commands Examples:
	cd, cd..			Navigate the directories in your shell
	ls					List the directory contents
	mkdir, rmdir		Create and remove directory using your shell
	touch, cat, echo	Create, read and print the contents of a file
	exit				Exit all the child processes and shell quits
