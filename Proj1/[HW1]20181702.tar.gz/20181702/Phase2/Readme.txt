<Project1 Phase 2: Redirection and Piping in Your Shell>

- Goal of This Phase:
	Implement commands with pipe(|)

- Usable Commands Examples:
	ls -al | grep filename
	cat filename | less
	cat filename | grep -v “abc” | sort – r
